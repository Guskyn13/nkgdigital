import portfolioImg from '../Assets/portfolioImg.jpg'
import p2 from '../Assets/p2.jpg'
import p3 from '../Assets/p3.jpg'
import p4 from '../Assets/p4.jpg'
import p5 from '../Assets/p5.jpg'

const projects = [
    {
        id: 1,
        name: 'Sanity Portfolio',
        desc: 'Personal website, build in React with Sanity backend. Detailed information regarding myself.',
        img: portfolioImg
    },
    {
        id: 2,
        name: 'Project 2',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ullamcorper, lorem non bibendum auctor, enim quam laoreet mi, eu tincidunt augue ipsum in ipsum. Quisque.',
        img: p2
    },
    {
        id: 3,
        name: 'Project 3',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ullamcorper, lorem non bibendum auctor, enim quam laoreet mi, eu tincidunt augue ipsum in ipsum. Quisque.',
        img: p3
    },
    {
        id: 4,
        name: 'Project 4',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ullamcorper, lorem non bibendum auctor, enim quam laoreet mi, eu tincidunt augue ipsum in ipsum. Quisque.',
        img: p4
    },
    {
        id: 5,
        name: 'Project 5',
        desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ullamcorper, lorem non bibendum auctor, enim quam laoreet mi, eu tincidunt augue ipsum in ipsum. Quisque.',
        img: p5
    },
]

export default projects;