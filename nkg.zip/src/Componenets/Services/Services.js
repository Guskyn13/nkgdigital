import React from 'react'
import './Services.css'

const Services = () => {
  return (
    <div className='services-container'>Services</div>
  )
}

export default Services